<?php
/*
https://edbq.xyz/test/amazon
 */
define ("MC_CLIENT_ID", "amzn1.application-oa2-client.ede7fbc64249410d9302a9983a75ec50");
define ("MC_CLIENT_SECRET", "d79ab79d312058c1cea9c90f82582878bfde69d383157023e0caa98c2b8bc182");
define ("MC_REDIRECT_URL", "https://edbq.xyz/test/amazon/auth.php");

include_once "functions.php";
$url = "https://www.amazon.com/ap/oa?client_id=". MC_CLIENT_ID
	."&scope=alexa::ask:skills:readwrite"
	."&response_type=code&redirect_uri=".urlencode(MC_REDIRECT_URL )
;
//die ($url);
//$res = mc_get_page_curl($url);

//print_r($res);
header("Location: ".$url);

/*
https://www.amazon.com/ap/oa?client_id=foodev
&scope=profile
&response_type=code
&state=208257577ll0975l93l2l59l895857093449424
&redirect_uri=https://client.example.com/auth_popup/token
*/



?>