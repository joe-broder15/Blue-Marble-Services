/*
call
npm install
and zip index.js + node_modules folder
before uploading to AWS Lambda

login url

https://edbq.xyz/test/amazon/



Client ID:
amzn1.application-oa2-client.ede7fbc64249410d9302a9983a75ec50

Client Secret:
d79ab79d312058c1cea9c90f82582878bfde69d383157023e0caa98c2b8bc182

"access_token": "
Atza|IwEBIEecgJpXgAJtOVg4c_dmL1wa2HGty5Ugxs0yot9VYA89kr2yazoBckhQkAjv7uOfofCyrk5Cyv3PnjSazXGdjO1CbZITBVInM5YwzijpFUYl8fVwxASLlZnHkz_gjOznzHJRifpfYaUkLMcyKuN5ssJqAEpB_9pJfUE1NWrWqpjcDc4KrxvqgVrmXf9wZj49d843h3gltXkqMDLCgdke2O4chu5f3SthDV2SvksxecWq4o5aFKuAOKIaUYtF4JvNn8-2lh304J6VpKczArH-Nxe8KvnE9CZiDUlOwTBhVLy1YLByUDP3M0sra64StllGC-zhds6BO2n_hHm2O6CGU9X_No9xpez6waBgNJ6x7qEm_sFyshvH1NAqa4-9xeSPHrBe8_Bb4NXDGpQOrc7Nsy-xc8GLWtBeRYxs_v4btmLndrj0hMWXmLNYLjqVH8p-DRr1-5dXb3l-uEID7JIVuMvYmGred7FOP5qPbRPLPxXt0ljZ56s2XrjnzWuPp1OZV56MfnJMDi0QKjEoKDhfv5wX
Atza|IwEBIEecgJpXgAJtOVg4c_dmL1wa2HGty5Ugxs0yot9VYA89kr2yazoBckhQkAjv7uOfofCyrk5Cyv3PnjSazXGdjO1CbZITBVInM5YwzijpFUYl8fVwxASLlZnHkz_gjOznzHJRifpfYaUkLMcyKuN5ssJqAEpB_9pJfUE1NWrWqpjcDc4KrxvqgVrmXf9wZj49d843h3gltXkqMDLCgdke2O4chu5f3SthDV2SvksxecWq4o5aFKuAOKIaUYtF4JvNn8-2lh304J6VpKczArH-Nxe8KvnE9CZiDUlOwTBhVLy1YLByUDP3M0sra64StllGC-zhds6BO2n_hHm2O6CGU9X_No9xpez6waBgNJ6x7qEm_sFyshvH1NAqa4-9xeSPHrBe8_Bb4NXDGpQOrc7Nsy-xc8GLWtBeRYxs_v4btmLndrj0hMWXmLNYLjqVH8p-DRr1-5dXb3l-uEID7JIVuMvYmGred7FOP5qPbRPLPxXt0ljZ56s2XrjnzWuPp1OZV56MfnJMDi0QKjEoKDhfv5wX
",
"refresh_token": "
Atzr|IwEBIBOR36Ua54WoXHOsLojQS11TUma5nnfuUC9Riq5Mq8fJJHJsKkBYkGteABtWq_WKHmbJtAD8LGMUicl5mbwsdpL_h9T7LN2B7ZmpCOHao1UsuN5JA-NVp6RxgX0uklxoLDt-_I9Mr_EKSHg8V7_ZOkPPj6jyPPxkhFyZEbrzG2qwcKFX6p8_oVjJyPvGTEtLZt_DO3UufkQAnBhFmyLZOpYuel7IOAVzE8Nz3m0pQoJtaVVzNiwRnNzC-95JEvJBlH3fp3ooTYW1PYne8Pyv5xWA4m2aZJLxZtCNt-42FX8COdXfkB3OP6TgnIdz7863N8boVweOqxZ5og1c_1mX4YKb6VKDYWqOrfLvjuYGL6CPiDmkJ3CgVJkmSQbdf5d7PNGsfIDALEAMVqipkd3B3LvOqs0M_xMkaAqwMVD7KjsTcESFg97dgWgDtufOkFVdjZ9ZQ4TVC2fkdGu3b_aZwh-zJtOME41usSsobs1aSc5RPUXeUg_Plpa7YM0vnfBMtCdPtLEBrMSMub2aEvvC1lmO
"
https://api.amazonalexa.com/v0
*/
/*
'use strict';

//var response = require('cfn-response');
var AWS = require('aws-sdk');
AWS.config.update({apiVersion: '2015-03-31'});

exports.handler = (event, context, callback) => {


	callback(null, JSON.stringify(event));

};
*/
var client_id = "amzn1.application-oa2-client.ede7fbc64249410d9302a9983a75ec50";
var client_secret = "d79ab79d312058c1cea9c90f82582878bfde69d383157023e0caa98c2b8bc182";
var access_token = "Atza|IwEBIGTZBBY-08pj8U4YCAsphOoIKJDC8wF7dkivWPxgf9T_HpB7HsraplzF60anIxcdtlgmgQUZAyU3dMHCZdQhhQCtsmQ6_O9x2hMlzsrmIzcw8klAlxqJVheglNpVKRd3vgMcJpShHu7yNwRD_8IDI39ipiGTIo7_f_FEanpvKG9SzcDqfkcWqvuvzKTU7XvfcNspgGRRM41hmDgcigguvbDMRfMvk3kzv6lpFE44OGE2FmKFYZ0RwLWapVtsBg31AWJ9qSGpx7lL5zg2X3efLQp5PqLojjgo8eGHnY-3w8X_WrNUXXsUWzntrH7qdMWQ2EeReEmiWL00R63HEl9nFQGWszDhR_ItGxfuBb5UlNHmsqH6MoFnz-DY6m4pjqrnehNFGhFahNlbvRUZ9bX2kfWLD4ZzQPkG1kTZU5Q9AFH8tMCAQs4_ZsZZJQbvd71rNkkL2C8Gygc-d0rdN611QQXE9wNxVNF-qtid5rSQzSRSGPl2JRXf2VGX7JeFmPHstAkceiW9XgtNkRsa36AX08PETSdtBjMOp1bG5a14IH9MUQ";
//var refresh_token ="Atzr|IwEBIBOR36Ua54WoXHOsLojQS11TUma5nnfuUC9Riq5Mq8fJJHJsKkBYkGteABtWq_WKHmbJtAD8LGMUicl5mbwsdpL_h9T7LN2B7ZmpCOHao1UsuN5JA-NVp6RxgX0uklxoLDt-_I9Mr_EKSHg8V7_ZOkPPj6jyPPxkhFyZEbrzG2qwcKFX6p8_oVjJyPvGTEtLZt_DO3UufkQAnBhFmyLZOpYuel7IOAVzE8Nz3m0pQoJtaVVzNiwRnNzC-95JEvJBlH3fp3ooTYW1PYne8Pyv5xWA4m2aZJLxZtCNt-42FX8COdXfkB3OP6TgnIdz7863N8boVweOqxZ5og1c_1mX4YKb6VKDYWqOrfLvjuYGL6CPiDmkJ3CgVJkmSQbdf5d7PNGsfIDALEAMVqipkd3B3LvOqs0M_xMkaAqwMVD7KjsTcESFg97dgWgDtufOkFVdjZ9ZQ4TVC2fkdGu3b_aZwh-zJtOME41usSsobs1aSc5RPUXeUg_Plpa7YM0vnfBMtCdPtLEBrMSMub2aEvvC1lmO";
var refresh_token ="Atzr|IwEBIBOR36Ua54WoXHOsLojQS11TUma5nnfuUC9Riq5Mq8fJJHJsKkBYkGteABtWq_WKHmbJtAD8LGMUicl5mbwsdpL_h9T7LN2B7ZmpCOHao1UsuN5JA-NVp6RxgX0uklxoLDt-_I9Mr_EKSHg8V7_ZOkPPj6jyPPxkhFyZEbrzG2qwcKFX6p8_oVjJyPvGTEtLZt_DO3UufkQAnBhFmyLZOpYuel7IOAVzE8Nz3m0pQoJtaVVzNiwRnNzC-95JEvJBlH3fp3ooTYW1PYne8Pyv5xWA4m2aZJLxZtCNt-42FX8COdXfkB3OP6TgnIdz7863N8boVweOqxZ5og1c_1mX4YKb6VKDYWqOrfLvjuYGL6CPiDmkJ3CgVJkmSQbdf5d7PNGsfIDALEAMVqipkd3B3LvOqs0M_xMkaAqwMVD7KjsTcESFg97dgWgDtufOkFVdjZ9ZQ4TVC2fkdGu3b_aZwh-zJtOME41usSsobs1aSc5RPUXeUg_Plpa7YM0vnfBMtCdPtLEBrMSMub2aEvvC1lmO";
var rp = require('request-promise');
var base_url = "https://api.amazonalexa.com/v0";
var url;
var func_arn = "arn:aws:lambda:us-east-1:504111962182:function:dynamic_function_1516128815336";

url = base_url + "/vendors";
console.log(url);
rp({
	method: 'GET',
	uri: url+"?client_id="+client_id+"&client_secret="+client_secret+"&access_token="+access_token,
	headers: {
		  'Content-Type': 'application/x-www-form-urlencoded',
			'Accept': 'application/json',
			'Authorization': access_token
	},
	json: true
}).then(function (res) {
	// POST succeeded...
	var vendor_id = res.vendors[0].id;
console.log("vendor_id = "+vendor_id);

	url = base_url + "/skills";
	var params = {
		"vendorId": vendor_id,
		"skillManifest": {
			"publishingInformation": {
				"locales": {
					"en-US": {
						"summary": "This is a sample Alexa skill.",
						"examplePhrases": [
							"Alexa, open sample skill.",
							"Alexa, turn on kitchen lights.",
							"Alexa, blink kitchen lights."
						],
						"keywords": [
							"Smart Home",
							"Lights",
							"Smart Devices"
						],
						"name": "Sample custom skill name.",
						"description": "This skill has basic and advanced smart devices control features."
					}
				},
				"isAvailableWorldwide": false,
				"testingInstructions": "1) Say 'Alexa, discover my devices' 2) Say 'Alexa, turn on sample lights'",
				"category": "SMART_HOME",
				"distributionCountries": [
					"US",
					"GB"
				]
			},
			"apis": {
				"custom": {
					"endpoint": {
						"uri": func_arn
					}
				}
			},
			"manifestVersion": "1.0",
			"privacyAndCompliance": {
				"allowsPurchases": false,
				"locales": {
					"en-US": {
						"termsOfUseUrl": "http://www.termsofuse.sampleskill.com",
						"privacyPolicyUrl": "http://www.myprivacypolicy.sampleskill.com"
					}
				},
				"isExportCompliant": true,
				"isChildDirected": false,
				"usesPersonalInfo": false
			}
		}
	};
	console.log(JSON.stringify(params));
	return rp({
		method: 'POST',
		uri: url + "/skills",
		body: params,
		headers: {
			'Accept': 'application/json',
			'Authorization': access_token
		},
		json: true
	}).then(function (res){
console.log("RESULT:",res);
	});

}).catch(function (err) {
		// POST failed..
		console.log("Error: ",err.statusCode);
		if (err.statusCode == 401) {
			rp({
				method: 'POST',
				uri: "https://api.amazon.com/auth/o2/token",
				form: {
					"grant_type": "refresh_token",
					"refresh_token": refresh_token,
					"client_id": client_id,
					"client_secret": client_secret
				},
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded',
					'Accept': 'application/json',
				}
			}).then(function (body) {
//				console.log("body2", body);
				var res = JSON.parse(body);
console.log(res.access_token);
				rp({
					method: 'GET',
					uri: url,
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
						'Accept': 'application/json',
						'Authorization': res.access_token
					}
				}).then(function (body) {

					console.log("body3", body);
				});
			});
		} // 401
});

/*

url = base_url + "/skills";
var params = {
	"vendorId": "M3NI7NRBST90BZ",
	"skillManifest": {
	"publishingInformation": {
		"locales": {
			"en-US": {
				"summary": "This is a sample Alexa skill.",
					"examplePhrases": [
					"Alexa, open sample skill.",
					"Alexa, turn on kitchen lights.",
					"Alexa, blink kitchen lights."
				],
					"keywords": [
					"Smart Home",
					"Lights",
					"Smart Devices"
				],
					"name": "Sample custom skill name.",
					"description": "This skill has basic and advanced smart devices control features."
			}
		},
		"isAvailableWorldwide": false,
			"testingInstructions": "1) Say 'Alexa, discover my devices' 2) Say 'Alexa, turn on sample lights'",
			"category": "SMART_HOME",
			"distributionCountries": [
			"US",
			"GB"
		]
	},
	"apis": {
		"custom": {
			"endpoint": {
				"uri": "arn:aws:lambda:us-east-1:032174894474:function:ask-custom-custome_cert"
			}
		}
	},
	"manifestVersion": "1.0",
		"privacyAndCompliance": {
		"allowsPurchases": false,
			"locales": {
			"en-US": {
				"termsOfUseUrl": "http://www.termsofuse.sampleskill.com",
					"privacyPolicyUrl": "http://www.myprivacypolicy.sampleskill.com"
			}
		},
		"isExportCompliant": true,
			"isChildDirected": false,
			"usesPersonalInfo": false
		}
	}
};
*/