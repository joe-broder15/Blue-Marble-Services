<?php
define ("MC_DEBUG",1);
define ("MC_DEBUG_CURL",1);

define("MC_LOG", "log.txt");

function mc_log( $msg ) {
	//if ( stripos(MCTEST_IP,",".$_SERVER["REMOTE_ADDR"]."," ) === false) return; // do not log other users
	if ( @filesize( MC_LOG ) > 100 * 1024 * 1024 )
		@unlink( MC_LOG );
	$cur_retry = 1;
	while ( $cur_retry <= 100 ) {
		@$fh = fopen( MC_LOG, "a" );
		if ( ! $fh ) {
			$cur_retry ++;
			continue;
		}
//			$s = sprintf("%1.3f",microtime(true))."\t".$msg."\n".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"]."\n\n";
		$s = @date("d.m.Y H:i:s.")."\t".$msg."\n".$_SERVER["REMOTE_ADDR"]."\n".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"]."\n\n";
		@fwrite( $fh, $s );
		@fclose( $fh );
		break;
	} // retry;
}


function mc_get_page_curl($url, $custom_header = null,  $timeout = 30, $cookie="", $referrer="", $proxy="", $retry=1) {
	if (defined("MC_DEBUG_CURL")) mc_log(">mc_get_page_curl url:\n$url\nHeader:\n".print_r($custom_header,true));
//    $proxy = "127.0.0.1:8888";
	$s = "";
	if ($curl = curl_init()) {
		$retry--;
		$agent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0";
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl,CURLOPT_ENCODING , "gzip");
		curl_setopt($curl, CURLOPT_USERAGENT, $agent);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 5);
		curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
		curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
//            curl_setopt($curl, CURLOPT_ENCODING, 'gzip');
		if (strlen($proxy) > 0)
			curl_setopt($curl, CURLOPT_PROXY, $proxy);
		
		if (strlen($referrer) > 0)
			curl_setopt($curl, CURLOPT_REFERER, $referrer);
		
		if (strncasecmp($url, "https", 5) == 0) {
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		}
		if (is_array($custom_header)) {
			curl_setopt($curl, CURLOPT_HTTPHEADER, $custom_header);
		}
		$s = curl_exec($curl);
		/*
				if($errno = curl_errno($curl)) {
						$error_message = curl_strerror($errno);
						echo "cURL error ({$errno}):\n {$error_message}";
				}
		*/
		$code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
//die("aaa $url status code = ".);
		curl_close($curl);
		$res = array("code" => $code, "response" => $s);
		if (defined("MC_DEBUG_CURL")) mc_log("<mc_get_json_curl CODE = $code\n".print_r($res["response"], true)."\n".$url);
		return $res;
	}
	if (defined("MC_DEBUG_CURL")) mc_log("<mc_get_json_curl CURL FAILS! ex = ".(int)function_exists("curl_init"));
	return array("code" => 500, "response" => "CURL DOES NOT WORK!");
}

function mc_post_json_curl($url, $method = "PUT", $params = "{}",  $custom_header = null, $timeout = 60, $cookie="", $referrer="", $proxy="", $retry=1) {
//    $proxy = "127.0.0.1:8888";
	$s = "";
	if (defined("MC_DEBUG_CURL")) mc_log(">mc_post_json_curl METHOD = $method\n$url\nPARAMS:\n$params\n".print_r($params, true)."\nHEADERS:\n".print_r($custom_header, true));
	if ($curl = curl_init()) {
		$retry--;
		$agent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0";
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl,CURLOPT_ENCODING , "gzip");
		curl_setopt($curl, CURLOPT_USERAGENT, $agent);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 5);
		$headers = ($custom_header) ? $custom_header : array();
		if ($method != "GET") {
			if (is_array($params) && ($method == "POST")) {
				curl_setopt($curl, CURLOPT_POST, 1);
				//$str = http_build_query($params);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
				$headers[] = 'Accept: application/json';
				$headers[] = 'Content-Type: application/x-www-form-urlencoded;charset=UTF-8';
//				$headers[] = 'Content-Length: ' . strlen($str);
//if (defined("MC_DEBUG_CURL")) mc_log("str=$str");
			} else {
				curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $params);  //Post Fields
				$headers[] = 'Accept: application/json';
				$headers[] = 'Content-Type: application/json';
				$headers[] = 'Content-Length: ' . strlen($params);
			}
		} else {
			$headers[] = "Accept: application/json";
		}
		if (count($headers) > 0)
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
		curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
//            curl_setopt($curl, CURLOPT_ENCODING, 'gzip');
		if (strlen($proxy) > 0)
			curl_setopt($curl, CURLOPT_PROXY, $proxy);
		
		if (strlen($referrer) > 0)
			curl_setopt($curl, CURLOPT_REFERER, $referrer);
		
		if (strncasecmp($url, "https", 5) == 0) {
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		}
//		curl_setopt($curl, CURLOPT_USERPWD, $tl_email.":".$tl_key);
		$s = curl_exec($curl);
		
				if($errno = curl_errno($curl)) {
						$error_message = curl_strerror($errno);
if (defined("MC_DEBUG_CURL")) mc_log("<mc_post_json_curl ERROR $errno\n$error_message\nMETHOD = $method\n$url\ns=$s\nPARAMS:\n$params\n".print_r($params, true)."\nHEADERS:\n".print_r($headers, true));
						//die ("cURL error ({$errno}):\n {$error_message}");
				}
		
		$code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		$res = array("code" => $code, "response" => json_decode($s, true));
		if (defined("MC_DEBUG_CURL")) mc_log("<mc_post_json_curl METHOD = $method code = $code\n$url\ns=$s\nPARAMS:\n$params\n".print_r($params, true)."\nHEADERS:\n".print_r($headers, true));

//die("aaa $url status code = ".);
		curl_close($curl);
		return $res;
	}
	return array("code" => 500, "response" => "CURL DOES NOT WORK!");
}
