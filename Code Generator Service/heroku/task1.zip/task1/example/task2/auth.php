<?php

define ("MC_CLIENT_ID", "amzn1.application-oa2-client.ede7fbc64249410d9302a9983a75ec50");
define ("MC_CLIENT_SECRET", "d79ab79d312058c1cea9c90f82582878bfde69d383157023e0caa98c2b8bc182");
define ("MC_REDIRECT_URL", "https://edbq.xyz/test/amazon/auth.php");

include_once "functions.php";

$json_data = @file_get_contents("php://input");
if (defined("MC_DEBUG")) mc_log(">json_data = $json_data\nREQUEST:\n".print_r($_REQUEST, true));
if (strpos(':',$json_data) !== false) {
	$ar = json_decode($json_data, true);
	if (defined("MC_DEBUG")) mc_log(">JSON:\n$json_data\n".print_r($ar,true));
	if (array_key_exists("access_token", $ar) !== false) {
		header("Content-Type: application/json");
		echo $json_data;
		exit(0);
	}
}

if (!array_key_exists("code", $_GET)){
	print_r($_REQUEST);
	die("<br>Access denied");
}

$code = $_GET["code"];
$url = "https://api.amazon.com/auth/o2/token";
$ar = array(
	"grant_type" => "authorization_code",
	"code" => $code,
	"redirect_uri" => MC_REDIRECT_URL,
	"client_id" => MC_CLIENT_ID,
	"client_secret" => MC_CLIENT_SECRET
);

$res = mc_post_json_curl($url, "POST", $ar);
print_r($res); die ("<br>Stop");


