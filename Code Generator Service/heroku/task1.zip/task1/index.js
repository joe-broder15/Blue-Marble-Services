/*
install on heroku:

$ sudo su
$ cd /home/leo/node.js/scott_lamda/heroku/task1/
$ nvm use 8.9.4
$ heroku login
$ heroku create
$ git add ./
$ git commit -m "init"
$ git push heroku master

Task1 EndPoint (create dynamic lambda from code & credentials passed in request body as JSON):
Method: POST

https://cryptic-river-76762.herokuapp.com/task1/
{
	"Code": "def create_response(text, shouldEndSession):\n    return {\n        'version': '1.0',\n        'sessionAttributes': {},\n        'response': {\n          'outputSpeech': {\n              'type': 'PlainText',\n              'text': text\n          },\n          'card': {\n              'type': 'Simple',\n              'title': 'testSkill',\n              'content': text\n          },\n          'reprompt': {\n              'outputSpeech': {\n                  'type': 'PlainText',\n                  'text': \"text\"\n              }\n          },\n          'shouldEndSession': shouldEndSession\n        }\n    }\n\n\ndef lambda_handler(event, context):\n\n    #on launch request prompt user to ask for help\n    if event['request']['type'] == 'LaunchRequest':\n        return create_response('If you dont know how to use me you can ask for help by saying help', False)\n\n    #give user utterances\n    elif event['request']['intent']['name'] == 'Help':\n        return create_response('There are several commands, try saying utterance 1', False)\n\n    #end session\n    elif event['request']['type'] == 'SessionEndedRequest':\n        return create_response('', True)\n\n    #end session\n    elif event['request']['intent']['name'] == 'endSession':\n        return create_response('', True)\n\n    #user defined intents\n    #paste content here\n    elif event['request']['intent']['name'] == 'intent':\n        return create_response('Response', True)\n\n",
	"Handler": "index.create_response",
	"Runtime": "python2.7",
	"AccessKeyId": "AKIAIOOBN2ZM5QDSBW7A",
	"SecretAccessKey": "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",
	"Role":	"arn:aws:iam::504111962182:role/service-role/role_api1",
	"Region": "us-east-1",
	"Timeout": 30
}

GIT:
https://git.heroku.com/cryptic-river-76762.git
 */
var express = require("express");
var bodyParser = require("body-parser");
var app = express();
var port = process.env.PORT || 5000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get('/', function(request, response) {
  response.send('Hello World!');
});


function createMemoryZipFromFunctionCode(code, callback) {
	/*
			var dotIndex = handler.indexOf('.');
			var fileName = handler.substring(0, dotIndex);
			var handlerFunctionName = handler.substring(dotIndex + 1, handler.length);
			var echoLambdaFunction =
				"'use strict';\n" +
				"exports." + handlerFunctionName + " = function(event, context) {\n" +
				"   console.log('Event:', JSON.stringify(event));\n" +
				"   context.succeed(event);\n" +
				"};";
	*/
	var JSZip = require('jszip');
	var zip = new JSZip();
	zip.file('index.py', code);
	console.log("code = ",code)
	zip.generateAsync({type:"nodebuffer"})
		.then(function (content) {
			// use content
console.log(content);
			callback(content);
		});
	//
}
/*
var event = {
	"Code": "def create_response(text, shouldEndSession):\n    return {\n        'version': '1.0',\n        'sessionAttributes': {},\n        'response': {\n          'outputSpeech': {\n              'type': 'PlainText',\n              'text': text\n          },\n          'card': {\n              'type': 'Simple',\n              'title': 'testSkill',\n              'content': text\n          },\n          'reprompt': {\n              'outputSpeech': {\n                  'type': 'PlainText',\n                  'text': \"text\"\n              }\n          },\n          'shouldEndSession': shouldEndSession\n        }\n    }\n\n\ndef lambda_handler(event, context):\n\n    #on launch request prompt user to ask for help\n    if event['request']['type'] == 'LaunchRequest':\n        return create_response('If you dont know how to use me you can ask for help by saying help', False)\n\n    #give user utterances\n    elif event['request']['intent']['name'] == 'Help':\n        return create_response('There are several commands, try saying utterance 1', False)\n\n    #end session\n    elif event['request']['type'] == 'SessionEndedRequest':\n        return create_response('', True)\n\n    #end session\n    elif event['request']['intent']['name'] == 'endSession':\n        return create_response('', True)\n\n    #user defined intents\n    #paste content here\n    elif event['request']['intent']['name'] == 'intent':\n        return create_response('Response', True)\n\n",
	"Handler": "index.create_response",
	"Runtime": "python2.7",
	"Role":	"arn:aws:iam::504111962182:role/service-role/role_api1",
	"Timeout": 30
};
*/
app.post('/task1/', function(request, response){
//	console.log(request.body);      // your JSON
	if (!request.body.hasOwnProperty("Runtime")) {
		response.status(400).send({"Error": "Runtime was not passed!"});
	}
	if (!request.body.hasOwnProperty("Role")) {
		response.status(400).send({"Error": "Role was not passed!"});
	}
	if (!request.body.hasOwnProperty("Code")) {
		response.status(400).send({"Error": "Code was not passed!"});
	}
	if (!request.body.hasOwnProperty("AccessKeyId")) {
		response.status(400).send({"Error": "AccessKeyId was not passed!"});
	}
	if (!request.body.hasOwnProperty("SecretAccessKey")) {
		response.status(400).send({"Error": "SecretAccessKey was not passed!"});
	}
	if (!request.body.hasOwnProperty("Region")) {
		response.status(400).send({"Error": "Region was not passed!"});
	}

	var AWS = require('aws-sdk');
	var fs = require('fs');
/*
	AWS.config.update({
		apiVersion: 			'2015-03-31',
		accessKeyId: 			request.body.AccessKeyId,
		secretAccessKey:	request.body.SecretAccessKey,
		region: 					request.body.Region
	});
*/
	fs.writeFileSync('./config.json', JSON.stringify({
		accessKeyId: 			request.body.AccessKeyId,
		secretAccessKey:	request.body.SecretAccessKey,
		region: 					request.body.Region

	},"utf-8"));
	AWS.config.loadFromPath('./config.json');
	var lambda = new AWS.Lambda({
		apiVersion: 			'2015-03-31',
		region: 					request.body.Region
	});

	var functionName = "dynamic_function_"+(new Date().getTime());

	createMemoryZipFromFunctionCode(request.body.Code, function (ZipContent){
		var params = {
			Code: 				{"ZipFile": ZipContent},
			Description: 	"Dynamic Lambda Function "+functionName,
			FunctionName: functionName,
			Handler: 			request.body.Handler || "index.handler", // is of the form of the name of your source file and then name of your function handler
			MemorySize: 	128,
			Publish: 			true,
			Role: 				request.body.Role, // replace with the actual arn of the execution role you created
			Runtime: 			request.body.Runtime,
			Timeout: 			request.body.Timeout || 30,
			VpcConfig: {
			}
		};
		console.log(params);
		lambda.createFunction(params, function(err, data) {
			if (err) {
				// Lambda creation failed, do not provide the physicalResourceId
				response.status(401).send({"Error": "Lamda function creation failed!", "AWS_error": err});
			}
			else {
				// Lambda creation succeeded, provide functionName as physicalResourceId so that this stack can delete it
//			response.send(event, context, response.SUCCESS, data, functionName);
				//callback(null, JSON.stringify(data));
				response.status(200).send(data);    // echo the result back
			}
		});
	});
});


app.listen(port, function() {
  console.log("Listening on " + port);
});